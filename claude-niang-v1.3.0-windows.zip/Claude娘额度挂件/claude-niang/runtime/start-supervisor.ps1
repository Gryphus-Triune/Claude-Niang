﻿$ErrorActionPreference='Stop'
$appDir=Split-Path $PSScriptRoot -Parent
. (Join-Path $PSScriptRoot 'supervisor-task.ps1')
. (Join-Path $PSScriptRoot 'log.ps1')
try{
  $info=Get-WidgetSupervisorInfo $appDir
  $installed=Get-WidgetSupervisorTask $info
  if($installed){Start-WidgetSupervisorTask $appDir}else{Register-WidgetSupervisorTask $appDir|Out-Null}
}catch{
  $failure=$_
  try{$configuration=Get-Content -LiteralPath (Join-Path $appDir 'installation.json') -Raw -Encoding UTF8|ConvertFrom-Json;Write-WidgetLog $configuration.dataDir 'supervisor' ('计划任务没能启动监督进程，改为直接运行：'+$failure.Exception.Message)}catch{}
  # Last resort: run the supervisor directly, as the Startup shortcut does.
  try{$fallback=Get-WidgetSupervisorInfo $appDir;Resume-WidgetSupervisor $appDir;Start-WidgetSupervisorProcess $fallback}catch{throw $failure}
}
