# 参与开发

使用 Node.js LTS（建议 22 或 24）和 Windows PowerShell 5.1。运行测试不需要登录 Claude，也不会访问真实 Claude 账号。

```powershell
cd claude-niang
npm test
npm run test:windows
```

提交前运行两组测试。模拟响应放在 `claude-niang/tests/fixtures`；新增样本请移除 Cookie、令牌、邮箱、真实组织名称和编号。不要提交 `installation.json`、运行数据、登录配置或个人图片。

额度只能由明确的用户操作读取。请为启动、恢复窗口、切组织、登录状态改变、并发请求和失败路径添加相应验证，避免重新引入后台查询。

在仓库根目录打包：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\build-release.ps1
```

构建只复制 `claude-niang/runtime/install-files.json` 白名单里的文件，生成 Claude 桌面扩展，以及 `dist` 中的发布 ZIP 与 SHA-256 校验文件。安装记录、日志和账号数据不会进入发布包。更新仓库里的 `Claude桌面扩展/claude-niang-usage.mcpb` 时，用发布 ZIP 里同名的文件替换。

`claude-niang/runtime/mcp.mjs` 是 MCP 服务的源码，它和后台进程共用 `runtime/shared.mjs`（管道地址、读取 JSON、金额与日期格式）。构建会把这两个文件复制成扩展内的 `server/index.mjs` 和 `server/shared.mjs`，把根目录的 `LICENSE` 复制进扩展，并从 `package.json` 同步扩展版本。服务运行时从扩展的 `manifest.json`（或挂件文件夹的 `package.json`）读取版本号，不需要手动同步。`shared.mjs` 不能引用其他本地模块，否则扩展里会缺文件。

挂件界面的入口是 `widget.ps1`，设置读写、窗口位置、气泡动画和额度显示分别在 `runtime/widget-settings.ps1`、`widget-placement.ps1`、`widget-bubble.ps1` 和 `widget-quota.ps1`。新增运行文件时，同时把它加进 `runtime/install-files.json`，否则安装检查和发布包都会缺它。

诊断信息统一写到数据文件夹的 `logs\claude-niang.log`：PowerShell 用 `runtime/log.ps1` 的 `Write-WidgetLog`，Node 用 `runtime/log.mjs` 的 `writeLog`。只写简短的启动、退出和出错说明，不要写 Cookie、令牌、邮箱或组织编号；同一条消息一分钟内只会记一次，不必自己限流。

默认形象是 `claude-niang/assets/claude-niang.png`。墨镜位置记在同目录的 `claude-niang.glasses.json` 里，其中的 SHA-256 必须和图片一致；换图后要重新标定位置和校验值，否则律动时不显示墨镜。

Windows 10、ARM64、微软商店版 Claude 和多屏高 DPI 需要实机反馈。报告问题时提供系统版本、Node 版本、安装路径是否含特殊字符和错误码即可，不要公开登录文件或完整的浏览器配置目录。
